package DTO;

public class MenuDTO {
	
	static String menuNumber;
	static String menuName;
	static String icehot;
	static String price;
	static String sumprice;
	
	public static String getMenuNumber() {
		return menuNumber;
	}
	public static void setMenuNumber(String menuNumber) {
		MenuDTO.menuNumber = menuNumber;
	}
	public static String getMenuName() {
		return menuName;
	}
	public static void setMenuName(String menuName) {
		MenuDTO.menuName = menuName;
	}
	public static String getIcehot() {
		return icehot;
	}
	public static void setIcehot(String icehot) {
		MenuDTO.icehot = icehot;
	}
	public static String getPrice() {
		return price;
	}
	public static void setPrice(String price) {
		MenuDTO.price = price;
	}
	public static String getSumprice() {
		return sumprice;
	}
	public static void setSumprice(String sumprice) {
		MenuDTO.sumprice = sumprice;
	}

}
