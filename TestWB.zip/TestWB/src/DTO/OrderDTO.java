package DTO;

public class OrderDTO {
	
	static String orderNum;
	static String custID;
	static String menuName;
	static String number;
	static String sumPrice;
	
	public static String getOrderNum() {
		return orderNum;
	}
	public static void setOrderNum(String orderNum) {
		OrderDTO.orderNum = orderNum;
	}
	public static String getCustID() {
		return custID;
	}
	public static void setCustID(String custID) {
		OrderDTO.custID = custID;
	}
	public static String getmenuName() {
		return menuName;
	}
	public static void setMenuName(String menuName) {
		OrderDTO.menuName = menuName;
	}
	public static String getnumber() {
		return number;
	}
	public static void setNumber(String number) {
		OrderDTO.number = number;
	}
	public static String getSumPrice() {
		return sumPrice;
	}
	public static void setSumPrice(String sumPrice) {
		OrderDTO.sumPrice = sumPrice;
	}
}
