package DTO;

public class UserDTO {
	
	static String custNum;
	static String custID;
	static String custPW;
	static String name;
	static String sex;
	static String tel;
	static String email;
	static String stamp;
	
	public static String getCustNum() {
		return custNum;
	}
	public static void setCustNum(String custNum) {
		UserDTO.custNum = custNum;
	}
	public static String getCustID() {
		return custID;
	}
	public static void setCustID(String custID) {
		UserDTO.custID = custID;
	}
	public static String getCustPW() {
		return custPW;
	}
	public static void setCustPW(String custPW) {
		UserDTO.custPW = custPW;
	}
	public static String getName() {
		return name;
	}
	public static void setName(String name) {
		UserDTO.name = name;
	}
	public static String getSex() {
		return sex;
	}
	public static void setSex(String sex) {
		UserDTO.sex = sex;
	}
	public static String getTel() {
		return tel;
	}
	public static void setTel(String tel) {
		UserDTO.tel = tel;
	}
	public static String getEmail() {
		return email;
	}
	public static void setEmail(String email) {
		UserDTO.email = email;
	}
	public static String getStamp() {
		return stamp;
	}
	public static void setStamp(String stamp) {
		UserDTO.stamp = stamp;
	}
	
	

}
