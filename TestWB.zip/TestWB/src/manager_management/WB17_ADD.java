package manager_management;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JTextPane;

public class WB17_ADD extends JFrame {

	private JPanel contentPane;
	private JTextField addressTxt;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField nameTxt;
	private JTextField timeTxt;

	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static String tmpstr;
	static ResultSet rs;
	static long count = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WB17_ADD frame = new WB17_ADD();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		dbConnect();
//		dbDis();
	}

	/**
	 * Create the frame.
	 */
	public WB17_ADD() {
		setTitle("\uC9C0\uC810\uCD94\uAC00");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 391, 373);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel_1_1 = new JLabel("\uC9C0\uC810\uCD94\uAC00");
		lblNewLabel_1_1.setFont(new Font("HY�߰���", Font.PLAIN, 20));
		lblNewLabel_1_1.setBounds(15, 15, 132, 31);
		contentPane.add(lblNewLabel_1_1);

		JLabel lblNewLabel = new JLabel("\uBD80\uC0B0 \uB0B4 \uAD6C\uC5ED");
		lblNewLabel.setBounds(145, 45, 80, 18);
		contentPane.add(lblNewLabel);

		addressTxt = new JTextField();
		addressTxt.setBounds(56, 136, 266, 49);
		contentPane.add(addressTxt);
		addressTxt.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("\uC9C0\uC810 \uC8FC\uC18C");
		lblNewLabel_1.setBounds(153, 110, 62, 18);
		contentPane.add(lblNewLabel_1);

		JButton btnNewButton = new JButton("\uCD94\uAC00");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (nameTxt.getText().isEmpty() || addressTxt.getText().isEmpty() || timeTxt.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "��ĭ�� ��� ä���ֽʽÿ�.");
				} else {
					try {
						update(nameTxt.getText(), addressTxt.getText(), timeTxt.getText());
						setVisible(false);
						new ADD().setVisible(true);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "�����߻�");
					}
				}

			}
		});

		btnNewButton.setBounds(75, 250, 105, 35);
		contentPane.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\uCDE8\uC18C");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new WB17().setVisible(true);
			}
		});
		btnNewButton_1.setBounds(194, 250, 105, 35);
		contentPane.add(btnNewButton_1);

		textField_1 = new JTextField();
		textField_1.setEditable(false);
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setText("\uB155\uCE74\uD398");
		textField_1.setBounds(74, 74, 68, 24);
		contentPane.add(textField_1);
		textField_1.setColumns(10);

		textField_2 = new JTextField();
		textField_2.setEditable(false);
		textField_2.setHorizontalAlignment(SwingConstants.CENTER);
		textField_2.setText("\uC810");
		textField_2.setBounds(265, 74, 29, 24);
		contentPane.add(textField_2);
		textField_2.setColumns(10);

		nameTxt = new JTextField();
		nameTxt.setBounds(146, 74, 116, 24);
		contentPane.add(nameTxt);
		nameTxt.setColumns(10);

		JLabel lblNewLabel_1_2 = new JLabel("\uC601\uC5C5\uC2DC\uAC04");
		lblNewLabel_1_2.setBounds(70, 205, 62, 18);
		contentPane.add(lblNewLabel_1_2);

		timeTxt = new JTextField();
		timeTxt.setColumns(10);
		timeTxt.setBounds(145, 201, 154, 24);
		contentPane.add(timeTxt);
	}

	public static void dbConnect() {
		driver = "sun.jdbc.odbc.JdbcOdbcDriver";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("����̹� �˻� ����!");
		} catch (ClassNotFoundException e) {
			System.err.println("error = " + e);
		}

		url = "jdbc:odbc:nyoung cafe";
		conn = null;
		stmt = null;
		rs = null;
		String url = "jdbc:mysql://localhost/nyoung cafe";
		String sql = "select * from office";
		try {

			conn = DriverManager.getConnection(url, "root", "apmsetup");

			stmt = conn.createStatement();

			rs = stmt.executeQuery(sql);

			System.out.println("�����ͺ��̽� ���� ����!");

		} catch (Exception e) {
			System.out.println("�����ͺ��̽� ���� ����!");
			e.printStackTrace();
		}
	}

	public static int query(String order, String sql) throws SQLException {
		int check = 0;
		if (order == "select") {
			rs = stmt.executeQuery(sql);
		} else {
			check = stmt.executeUpdate(sql);
		}
		return check;
	}

	public static void update(String branchName, String branchLocation, String time) throws SQLException {
		System.out.println(branchName + "," + branchLocation + "," + time);
		int check = query("insert", "insert into office(branchName, branchLocation, time) values ('" + branchName
				+ "', '" + branchLocation + "', '" + time + "')");
		System.out.println(check);
		JOptionPane.showMessageDialog(null, "���� �߰� �Ϸ�!");
	}

	public static void dbDis() {
		try {
			if (conn != null)
				conn.close();
			if (stmt != null)
				stmt.close();
			System.out.println("�����ͺ��̽� ���� ����!");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
