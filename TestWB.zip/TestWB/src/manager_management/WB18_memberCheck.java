package manager_management;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class WB18_memberCheck extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JTable table;
	
	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static String tmpstr;
	static ResultSet rs;
	static long count = 0;
	
	static String[] head = new String[] { "ȸ�����̵�", "ȸ����", "����", "��ȭ��ȣ" };
	static DefaultTableModel model1 = new DefaultTableModel(head, 0);

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) throws SQLException {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WB18_memberCheck frame = new WB18_memberCheck();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		dbConnect();
		query("select", "select * from user where custNum = 1");
		count = 1;
		viewData();
		dbDis();
		
	}

	/**
	 * Create the frame.
	 */
	public WB18_memberCheck() {
		setTitle("\uD68C\uC6D0\uC870\uD68C");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 391, 632);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton_2 = new JButton("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			setVisible(false);
			new WB14_managerMain(null, null).setVisible(true);
			}
		});
		btnNewButton_2.setBounds(281, 0, 92, 46);
		contentPane.add(btnNewButton_2);
		
		JLabel lblNewLabel_1_1 = new JLabel("\uD68C\uC6D0\uC870\uD68C");
		lblNewLabel_1_1.setFont(new Font("HY�߰���", Font.PLAIN, 20));
		lblNewLabel_1_1.setBounds(15, 15, 152, 31);
		contentPane.add(lblNewLabel_1_1);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(14, 75, 340, 442);
		contentPane.add(panel);
		panel.setLayout(null);

		table = new JTable(model1);
		table.setFont(new Font("����", Font.PLAIN, 14));
		table.setPreferredScrollableViewportSize(new Dimension(200, 400));
		table.setFillsViewportHeight(true);

		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(0, 0, 340, 442);
		panel.add(scrollPane);
		scrollPane.setViewportView(table);

		contentPane.setVisible(true);

	}
	
	public static void dbConnect() {
		driver = "sun.jdbc.odbc.JdbcOdbcDriver";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("����̹� �˻� ����!");
		} catch (ClassNotFoundException e) {
			System.err.println("error = " + e);
		}

		url = "jdbc:odbc:nyoung cafe";
		conn = null;
		stmt = null;
		rs = null;
		String url = "jdbc:mysql://localhost/nyoung cafe";
		String sql = "Select * From user";
		try {

			conn = DriverManager.getConnection(url, "root", "apmsetup");

			stmt = conn.createStatement();

			rs = stmt.executeQuery(sql);

			System.out.println("�����ͺ��̽� ���� ����!");

		} catch (Exception e) {
			System.out.println("�����ͺ��̽� ���� ����!");
			e.printStackTrace();
		}
	}

	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			rs = stmt.executeQuery(sql);
		} else {
			stmt.executeUpdate(sql);
		}
	}

	public static void viewData() throws SQLException {
		if (!rs.next()) {
			System.out.println("!rs.next()");
			count--;
		} else {
			try {
				query("select", "select * from user");

				while (rs.next()) {
					model1.addRow(new Object[] { rs.getString("custID"), rs.getString("name"),
							rs.getString("sex"), rs.getString("tel") });
				}
			} catch (Exception e1) {
				e1.getStackTrace();
			}
		}
	}

	public static void dbDis() {
		try {
			if (conn != null)
				conn.close();
			if (stmt != null)
				stmt.close();
			System.out.println("�����ͺ��̽� ���� ����!");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
