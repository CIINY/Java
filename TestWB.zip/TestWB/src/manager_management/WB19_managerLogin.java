package manager_management;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import user_package.WB12_New;
import user_package.WB3_login;

public class WB19_managerLogin extends JFrame {

	private JPanel contentPane;
	private JTextField idTxt;
	private JPasswordField passwordField;

	static Label num, name, tel;
	static TextField num_t, name_t, tel_t;
	JButton reloaddown, reloadup, save, update, delete;
	Panel pan1, pan2, pan3, pan4;

	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	static long count = 0;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WB19_managerLogin frame = new WB19_managerLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}
	

	
	public WB19_managerLogin() {
		setTitle("Login_Manager");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 391, 632);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(204, 204, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		// contentPane.setLayout(new BorderLayout(0, 0));
		contentPane.setLayout(null); // windowȭ�鿡 ��ġ����� �����϶�. ���ϰ� �ƹ����� �ø���� �� (Layout�� ���ֶ�)
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 16));
		lblNewLabel.setBounds(88, 196, 78, 15);
		contentPane.add(lblNewLabel);

		idTxt = new JTextField();
		idTxt.setToolTipText("");
		idTxt.setColumns(10);
		idTxt.setBounds(147, 191, 141, 27);
		contentPane.add(idTxt);

		passwordField = new JPasswordField();
		passwordField.setToolTipText("");
		passwordField.setBounds(147, 245, 141, 27);
		contentPane.add(passwordField);

		JButton btnNewButton = new JButton("\uB85C\uADF8\uC778");
		btnNewButton.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {

				String pw = "";
				char[] secret_pw = passwordField.getPassword();

				for (char cha : secret_pw) {
					Character.toString(cha);
					pw += (pw.equals("")) ? "" + cha + "" : "" + cha + "";
				}
				if (idTxt.getText().isEmpty() || passwordField.getPassword().toString().isEmpty())
					JOptionPane.showMessageDialog(null, "�Է�ĭ�� ä���ֽʽÿ�.");
				else {
					try {
						if (loginManager(idTxt.getText(), pw) == 1) {
							setVisible(false);
							new WB14_managerMain(idTxt.getText(), pw).setVisible(true);
						} else {
							JOptionPane.showMessageDialog(null, "��ϵ��� ���� ���̵�ų� Ʋ�� ��й�ȣ�Դϴ�.");
						}
					} catch (Exception e2) {
						// TODO: handle exception
						e2.printStackTrace();
					}
				}
			}
		});
		btnNewButton.setBounds(150, 307, 78, 27);
		contentPane.add(btnNewButton);

		JLabel lblNewLabel_1 = new JLabel("PW");
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 16));
		lblNewLabel_1.setBounds(88, 250, 91, 15);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("NYoung");
		lblNewLabel_2.setFont(new Font("Dialog", Font.BOLD, 49));
		lblNewLabel_2.setBounds(88, 53, 200, 58);
		contentPane.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("Cafe");
		lblNewLabel_3.setFont(new Font("Dialog", Font.BOLD, 30));
		lblNewLabel_3.setBounds(147, 114, 91, 48);
		contentPane.add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("\uB9E4\uB2C8\uC800 \uB85C\uADF8\uC778 \uD654\uBA74 \uC785\uB2C8\uB2E4.");
		lblNewLabel_4.setBounds(14, 567, 183, 18);
		contentPane.add(lblNewLabel_4);
		
		JButton btnNewButton_2 = new JButton("\uB3CC\uC544\uAC00\uAE30");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			setVisible(false);
			new WB3_login().setVisible(true);
			}
		});
		btnNewButton_2.setFont(new Font("����", Font.PLAIN, 12));
		btnNewButton_2.setBounds(260, 560, 105, 27);
		contentPane.add(btnNewButton_2);
		// image.setSzie(296.260);
		setResizable(false);
		setVisible(true);
		


	}
	
	public static void dbConnectManager() {
		driver = "sun.jdbc.odbc.JdbcOdbcDriver";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("����̹� �˻� ����!");
		} catch (ClassNotFoundException e) {
			System.err.println("error = " + e);
		}

		url = "jdbc:odbc:nyoung cafe";
		conn = null;
		stmt = null;
		rs = null;
		String url = "jdbc:mysql://localhost/nyoung cafe";
		String sql = "Select * From manager";
		try {

			conn = DriverManager.getConnection(url, "root", "apmsetup");

			stmt = conn.createStatement();

			rs = stmt.executeQuery(sql);

			System.out.println("�����ͺ��̽� ���� ����!");

		} catch (Exception e) {
			System.out.println("�����ͺ��̽� ���� ����!");
			e.printStackTrace();
		}
	}
	
	public static void dbDis() {
		try {
			if (conn != null)
				conn.close();
			if (stmt != null)
				stmt.close();
			System.out.println("�����ͺ��̽� ���� ����!");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public static int loginManager(String id, String pw) throws SQLException {

		dbConnectManager();
		
		rs = stmt.executeQuery("select * from manager where ID ='" + id + "'");
		
		if (rs.next() == true) {
			String pwd = rs.getString("PW");
			System.out.println(pwd);
			System.out.println(pw);
			if (pwd.equals(pw)) {
				dbDis();
				return 1;
			} else {
				dbDis();
				return 0;
			}
		} else {
			dbDis();
			return 0;
		}

	}

}
