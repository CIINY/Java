package user_package;

import java.awt.Font;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class WB12_New extends JFrame {

	private JPanel contentPane;
	private JTextField idTxt, pwTxt, emailTxt, nameTxt, telTxt1, telTxt2;

	static Label custID_l, custPW_l, custName_l, custTel_l, custEmail_l;
	JButton reloaddown, reloadup, save, update, delete;
	Panel pan1, pan2, pan3, pan4;

	private final JRadioButton female;
	private JRadioButton male;

	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	static long count = 0;

	private boolean duplicate;

	/**
	 * Launch the application.
	 */

// ȭ�� �׽�Ʈ �Ҷ��� ����!
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					WB12_New frame = new WB12_New();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//		
//	}

	/**
	 * Create the frame.
	 */

	public WB12_New() {
		setTitle("\uD68C\uC6D0\uAC00\uC785");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 391, 632);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("\u25C6 \uC815\uBCF4\uB97C \uC785\uB825\uD558\uC2ED\uC2DC\uC624.");
		lblNewLabel.setFont(new Font("���ʷҹ���", Font.BOLD, 17));
		lblNewLabel.setBounds(14, 54, 181, 31);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("\uD68C\uC6D0\uAC00\uC785");
		lblNewLabel_1.setFont(new Font("HY�߰���", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(15, 12, 132, 31);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("ID");
		lblNewLabel_2.setFont(new Font("Calibri", Font.PLAIN, 25));
		lblNewLabel_2.setBounds(20, 365, 62, 18);
		contentPane.add(lblNewLabel_2);

		JLabel lblNewLabel_2_1 = new JLabel("PW");
		lblNewLabel_2_1.setFont(new Font("Calibri", Font.PLAIN, 25));
		lblNewLabel_2_1.setBounds(20, 405, 62, 18);
		contentPane.add(lblNewLabel_2_1);

		idTxt = new JTextField();
		idTxt.setBounds(71, 360, 147, 24);
		contentPane.add(idTxt);
		idTxt.setColumns(10);

		pwTxt = new JTextField();
		pwTxt.setColumns(10);
		pwTxt.setBounds(71, 400, 147, 24);
		contentPane.add(pwTxt);

		JButton btnNewButton = new JButton("\uC911\uBCF5\uD655\uC778");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					if (duplicateCheck(idTxt.getText()) == 1) {
						System.out.println("�ߺ��� ���̵� �Դϴ�.");
						JOptionPane.showMessageDialog(null, "�ߺ��� ���̵� �Դϴ�.");
						duplicate = false;
					} else {
						System.out.println("��밡���� ���̵� �Դϴ�.");
						JOptionPane.showMessageDialog(null, "��밡���� ���̵� �Դϴ�.");
						duplicate = true;
					}

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

		btnNewButton.setBounds(237, 358, 105, 27);
		contentPane.add(btnNewButton);

		JLabel lblNewLabel_2_2 = new JLabel("E-MAIL");
		lblNewLabel_2_2.setFont(new Font("Calibri", Font.PLAIN, 25));
		lblNewLabel_2_2.setBounds(20, 280, 89, 18);
		contentPane.add(lblNewLabel_2_2);

		emailTxt = new JTextField();
		emailTxt.setBounds(23, 310, 116, 24);
		contentPane.add(emailTxt);
		emailTxt.setColumns(10);

		JLabel golbang = new JLabel("@");
		golbang.setFont(new Font("��������", Font.PLAIN, 20));
		golbang.setBounds(151, 313, 27, 18);
		contentPane.add(golbang);

		JComboBox mail = new JComboBox();
		mail.setBounds(181, 310, 147, 24);
		contentPane.add(mail);

		mail.addItem("naver.com");
		mail.addItem("gmail.com");
		mail.addItem("daum.net");

		JLabel lblNewLabel_2_3 = new JLabel("\uC774\uB984");
		lblNewLabel_2_3.setFont(new Font("HY�׷���M", Font.BOLD, 18));
		lblNewLabel_2_3.setBounds(20, 100, 62, 18);
		contentPane.add(lblNewLabel_2_3);

		nameTxt = new JTextField();
		nameTxt.setBounds(70, 97, 116, 24);
		contentPane.add(nameTxt);
		nameTxt.setColumns(10);

		JLabel lblNewLabel_2_3_1 = new JLabel("\uC804\uD654\uBC88\uD638");
		lblNewLabel_2_3_1.setFont(new Font("HY�׷���M", Font.BOLD, 18));
		lblNewLabel_2_3_1.setBounds(20, 190, 83, 18);
		contentPane.add(lblNewLabel_2_3_1);

		JLabel lblNewLabel_2_3_2 = new JLabel("\uC131\uBCC4");
		lblNewLabel_2_3_2.setFont(new Font("HY�׷���M", Font.BOLD, 18));
		lblNewLabel_2_3_2.setBounds(20, 145, 62, 18);
		contentPane.add(lblNewLabel_2_3_2);

		male = new JRadioButton("\uB0A8\uC131");
		male.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (male.isSelected()) {
					female.setSelected(false);
				}
			}
		});
		male.setBounds(80, 143, 57, 27);
		contentPane.add(male);

		female = new JRadioButton("\uC5EC\uC131");
		female.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (female.isSelected()) {
					male.setSelected(false);
				}
			}
		});

		female.setBounds(150, 139, 62, 36);
		contentPane.add(female);

		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setBounds(25, 220, 50, 24);
		contentPane.add(comboBox_2);

		comboBox_2.addItem("010");
		comboBox_2.addItem("011");

		telTxt1 = new JTextField();
		telTxt1.setBounds(105, 220, 63, 24);
		contentPane.add(telTxt1);
		telTxt1.setColumns(10);

		telTxt2 = new JTextField();
		telTxt2.setColumns(10);
		telTxt2.setBounds(192, 220, 63, 24);
		contentPane.add(telTxt2);

		JLabel lblNewLabel_4 = new JLabel("-");
		lblNewLabel_4.setBounds(85, 224, 18, 18);
		contentPane.add(lblNewLabel_4);

		JLabel lblNewLabel_4_1 = new JLabel("-");
		lblNewLabel_4_1.setBounds(177, 224, 18, 18);
		contentPane.add(lblNewLabel_4_1);

		JButton btnNewButton_1 = new JButton("\uAC00\uC785");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String tel = (String) comboBox_2.getSelectedItem() + telTxt1.getText() + telTxt2.getText();
				String sex;
				
				String email = emailTxt.getText() + (String) "@" + (String) mail.getSelectedItem();

				if (female.isSelected()) {
					sex = "female";
				} 
				else if(male.isSelected()) {
					sex = "male";
				}
				else {
					sex = "0";
				}
				
				if (idTxt.getText().isEmpty() || pwTxt.getText().isEmpty() || nameTxt.getText().isEmpty() || tel.isEmpty() || email.isEmpty() || sex == "0") {
					JOptionPane.showMessageDialog(null, "��ĭ�� ��� ä���ֽʽÿ�.");
				} else {

					if (!duplicate) {
						System.out.println("���̵� �ߺ���");
						JOptionPane.showMessageDialog(null, "���̵� �ߺ��Դϴ�.");
					} else {
						try {
							register(idTxt.getText(), pwTxt.getText(), nameTxt.getText(), tel, email, sex);
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
							JOptionPane.showMessageDialog(null, "�����߻�");
						}
					}

				}
			}
		});
		btnNewButton_1.setBounds(20, 455, 333, 48);
		contentPane.add(btnNewButton_1);

		JButton btnNewButton_1_1 = new JButton("\uCDE8\uC18C");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new WB3_login().setVisible(true);
			}
		});
		btnNewButton_1_1.setBounds(20, 515, 333, 42);
		contentPane.add(btnNewButton_1_1);
	}

//##################################################################################### - DB connect

	public static void dbConnect() {
		driver = "sun.jdbc.odbc.JdbcOdbcDriver";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("����̹� �˻� ����!");
		} catch (ClassNotFoundException e) {
			System.err.println("error = " + e);
		}

		url = "jdbc:odbc:nyoung cafe";
		conn = null;
		stmt = null;
		rs = null;
		String url = "jdbc:mysql://localhost/nyoung cafe";
		String sql = "Select * From user";
		try {

			conn = DriverManager.getConnection(url, "root", "apmsetup");

			stmt = conn.createStatement();

			rs = stmt.executeQuery(sql);

			System.out.println("�����ͺ��̽� ���� ����!");

		} catch (Exception e) {
			System.out.println("�����ͺ��̽� ���� ����!");
			e.printStackTrace();
		}
	}

	public static void dbDis() {
		try {
			if (conn != null)
				conn.close();
			if (stmt != null)
				stmt.close();
			System.out.println("�����ͺ��̽� ���� ����!");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

//##################################################################################### - Query

	public static int query(String order, String sql) throws SQLException {

		dbConnect();

		int result = 1;

		if (order == "select") {
			rs = stmt.executeQuery(sql);

			if (rs.next() == false) {
				result = 0;
			} else {
				result = 1;
			}

		}

		// update, insert, delete�� �����
		else {
			result = stmt.executeUpdate(sql);
		}

		dbDis();

		return result;

	}

	// �ߺ�Ȯ��
	public static int duplicateCheck(String id) throws SQLException {
		int check = query("select", "select custID from user where custID =" + id + "");
		System.out.println(check);
		return check;
	}

	// ȸ������
	public static void register(String id, String pw, String name, String tel, String email, String sex)
			throws SQLException {
		System.out.println(id + "," + pw + "," + name + "," + tel + "," + email + "," + sex);
		int check = query("insert", "insert into user(custID, custPW, name, sex, tel, email) values ('" + id + "', '"
				+ pw + "', '" + name + "', '" + sex + "', '" + tel + "', '" + email + "')");
		System.out.println(check);
		JOptionPane.showMessageDialog(null, "ȸ������ �Ϸ�!");
	}

}