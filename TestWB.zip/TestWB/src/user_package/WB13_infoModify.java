package user_package;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import DTO.UserDTO;

public class WB13_infoModify extends JFrame {

	private JPanel contentPane;
	private JTextField pwTxt;
	private JTextField idTxt;
	private JTextField emailTxt;
	private JTextField telTxt;

	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	static long count = 0;

	/**
	 * Launch the application.
	 */

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WB13_infoModify frame = new WB13_infoModify(null, null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public WB13_infoModify(String id, String pw) throws SQLException {

		dbConnect();

		setTitle("\uD68C\uC6D0\uC815\uBCF4 \uC218\uC815");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 391, 632);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.setLayout(null);
		
		telTxt = new JTextField();
		telTxt.setBounds(22, 355, 331, 24);
		contentPane.add(telTxt);
		telTxt.setColumns(10);

		JLabel lblNewLabel = new JLabel("\u25C6 \uC815\uBCF4\uB97C \uC785\uB825\uD558\uC2ED\uC2DC\uC624.");
		lblNewLabel.setFont(new Font("���ʷҹ���", Font.BOLD, 17));
		lblNewLabel.setBounds(14, 54, 181, 31);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("\uD68C\uC6D0\uC815\uBCF4 \uC218\uC815");
		lblNewLabel_1.setFont(new Font("HY�߰���", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(15, 12, 132, 31);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("ID");
		lblNewLabel_2.setFont(new Font("Calibri", Font.PLAIN, 25));
		lblNewLabel_2.setBounds(20, 110, 62, 18);
		contentPane.add(lblNewLabel_2);

		JLabel lblNewLabel_2_1 = new JLabel("PW");
		lblNewLabel_2_1.setFont(new Font("Calibri", Font.PLAIN, 25));
		lblNewLabel_2_1.setBounds(20, 150, 62, 18);
		contentPane.add(lblNewLabel_2_1);

		pwTxt = new JTextField();
		pwTxt.setEditable(false);
		pwTxt.setColumns(10);
		pwTxt.setBounds(85, 145, 147, 24);
		contentPane.add(pwTxt);

		idTxt = new JTextField();
		idTxt.setEditable(false);
		idTxt.setColumns(10);
		idTxt.setBounds(85, 105, 147, 24);
		contentPane.add(idTxt);

		JLabel lblNewLabel_2_2 = new JLabel("E-MAIL");
		lblNewLabel_2_2.setFont(new Font("Calibri", Font.PLAIN, 25));
		lblNewLabel_2_2.setBounds(20, 215, 89, 18);
		contentPane.add(lblNewLabel_2_2);

		emailTxt = new JTextField();
		emailTxt.setColumns(10);
		emailTxt.setBounds(22, 250, 331, 24);
		contentPane.add(emailTxt);

		JLabel lblNewLabel_2_3_1 = new JLabel("\uC804\uD654\uBC88\uD638");
		lblNewLabel_2_3_1.setFont(new Font("HY�׷���M", Font.BOLD, 18));
		lblNewLabel_2_3_1.setBounds(20, 325, 83, 18);
		contentPane.add(lblNewLabel_2_3_1);

		JButton btnNewButton_1 = new JButton("\uC218\uC815");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				
				if(emailTxt.getText().isEmpty() || telTxt.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "��ĭ�� ��� ä���ֽʽÿ�.");
				} else {
					try{ 
						modify(idTxt.getText(), pwTxt.getText(), emailTxt.getText(), telTxt.getText());
						JOptionPane.showMessageDialog(null, "ȸ������ ���� �Ϸ�!");
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "�����߻�");
					}	
				}
//				UserDTO.setName(idTxt.getText());
//				UserDTO.setCustPW(pw);
				
				
				
				// try {
//					new WB4_info(id, pw).setVisible(true);
//				} catch (SQLException e1) {
//					// TODO Auto-generated catch block
//					e1.printStackTrace();
//				}
			}
		});
		btnNewButton_1.setBounds(20, 455, 333, 48);
		contentPane.add(btnNewButton_1);

		JButton btnNewButton_1_1 = new JButton("\uCDE8\uC18C");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				try {
					new WB4_info(id, pw).setVisible(true);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_1_1.setBounds(20, 515, 333, 42);
		contentPane.add(btnNewButton_1_1);

		idTxt.setText(UserDTO.getCustID());
		pwTxt.setText(UserDTO.getCustPW());
		emailTxt.setText(UserDTO.getEmail());
		telTxt.setText(UserDTO.getTel());
	}

	// #####################################################################################
	// - DB connect

	public static void dbConnect() {
		driver = "sun.jdbc.odbc.JdbcOdbcDriver";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("����̹� �˻� ����!");
		} catch (ClassNotFoundException e) {
			System.err.println("error = " + e);
		}

		url = "jdbc:odbc:nyoung cafe";
		conn = null;
		stmt = null;
		rs = null;
		String url = "jdbc:mysql://localhost/nyoung cafe";
		String sql = "Select * From user";
		try {

			conn = DriverManager.getConnection(url, "root", "apmsetup");

			stmt = conn.createStatement();

			rs = stmt.executeQuery(sql);

			System.out.println("�����ͺ��̽� ���� ����!");

		} catch (Exception e) {
			System.out.println("�����ͺ��̽� ���� ����!");
			e.printStackTrace();
		}
	}

	public static void dbDis() {
		try {
			if (conn != null)
				conn.close();
			if (stmt != null)
				stmt.close();
			System.out.println("�����ͺ��̽� ���� ����!");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	// #####################################################################################
	// - Query

	public static int query(String order, String sql) throws SQLException {

		dbConnect();

		int result = 1;

		if (order == "select") {
			rs = stmt.executeQuery(sql);

			if (rs.next() == false) {
				result = 0;
			} else {
				result = 1;
			}

		}

		// update, insert, delete�� �����
		else {
			result = stmt.executeUpdate(sql);
		}

		dbDis();

		return result;

	}	

	// ȸ������
	public static void modify(String id, String pw, String tel, String email)
			throws SQLException {
		System.out.println(id + "," + pw + "," + tel + "," + email);	
		int check = query("update", "update user set tel = "+tel+", email="+email+" where custID = '"+id+"'");
		System.out.println(check);
	}

}
