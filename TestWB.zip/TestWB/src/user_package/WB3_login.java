package user_package;
import DTO.UserDTO;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import manager_management.WB19_managerLogin;

public class WB3_login extends JFrame {

	private JPanel contentPane;
	private JTextField idTxt;
	private JPasswordField passwordField;

	static Label num, name, tel;
	static TextField num_t, name_t, tel_t;
	JButton reloaddown, reloadup, save, update, delete;
	Panel pan1, pan2, pan3, pan4;

	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	static long count = 0;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WB3_login frame = new WB3_login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	

	public WB3_login() {
		setTitle("Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 391, 632);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(204, 204, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		// contentPane.setLayout(new BorderLayout(0, 0));
		contentPane.setLayout(null); // windowȭ�鿡 ��ġ����� �����϶�. ���ϰ� �ƹ����� �ø���� �� (Layout�� ���ֶ�)
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 16));
		lblNewLabel.setBounds(88, 196, 78, 15);
		contentPane.add(lblNewLabel);

		idTxt = new JTextField();
		idTxt.setToolTipText("");
		idTxt.setColumns(10);
		idTxt.setBounds(147, 191, 141, 27);
		contentPane.add(idTxt);

		passwordField = new JPasswordField();
		passwordField.setToolTipText("");
		passwordField.setBounds(147, 245, 141, 27);
		contentPane.add(passwordField);

		JButton btnNewButton = new JButton("\uB85C\uADF8\uC778");
		btnNewButton.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {

				String pw = "";
				char[] secret_pw = passwordField.getPassword();

				for (char cha : secret_pw) {
					Character.toString(cha);
					pw += (pw.equals("")) ? "" + cha + "" : "" + cha + "";
				}

				if (idTxt.getText().isEmpty() || passwordField.getPassword().toString().isEmpty())
					JOptionPane.showMessageDialog(null, "�Է�ĭ�� ä���ֽʽÿ�.");
				else {
					try {
						if (login(idTxt.getText(), pw) == 1) {
							setVisible(false);
							UserDTO.setCustID(idTxt.getText());
							UserDTO.setCustPW(pw);
							new WB2_main(idTxt.getText(), pw).setVisible(true);
						} else {
							JOptionPane.showMessageDialog(null, "��ϵ��� ���� ���̵�ų� Ʋ�� ��й�ȣ�Դϴ�.");
						}
					} catch (Exception e2) {
						// TODO: handle exception
						e2.printStackTrace();
					} 
				}
			}
		});
		btnNewButton.setBounds(88, 307, 78, 27);
		contentPane.add(btnNewButton);

		JLabel lblNewLabel_1 = new JLabel("PW");
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 16));
		lblNewLabel_1.setBounds(88, 250, 91, 15);
		contentPane.add(lblNewLabel_1);

		JButton btnNewButton_1 = new JButton("\uD68C\uC6D0\uAC00\uC785");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				new WB12_New().setVisible(true);

			}
		});

		btnNewButton_1.setBounds(194, 307, 94, 27);
		contentPane.add(btnNewButton_1);

		JLabel lblNewLabel_2 = new JLabel("NYoung");
		lblNewLabel_2.setFont(new Font("Dialog", Font.BOLD, 49));
		lblNewLabel_2.setBounds(88, 53, 200, 58);
		contentPane.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("Cafe");
		lblNewLabel_3.setFont(new Font("Dialog", Font.BOLD, 30));
		lblNewLabel_3.setBounds(147, 114, 91, 48);
		contentPane.add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("\uBD80\uC0B0 \uB0B4\uC5D0\uB9CC \uC788\uC2B5\uB2C8\uB2E4!");
		lblNewLabel_4.setBounds(14, 567, 152, 18);
		contentPane.add(lblNewLabel_4);
		
		JButton btnNewButton_2 = new JButton("\uAD00\uB9AC\uC790 \uB85C\uADF8\uC778\uC73C\uB85C \uAC00\uAE30");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			setVisible(false);
			new WB19_managerLogin().setVisible(true);
			}
		});
		btnNewButton_2.setFont(new Font("����", Font.PLAIN, 12));
		btnNewButton_2.setBounds(200, 560, 165, 27);
		contentPane.add(btnNewButton_2);
		// image.setSzie(296.260);
		setResizable(false);
		setVisible(true);

	}

	// #####################################################################################
	// - DB connect

	public static void dbConnect() {
		driver = "sun.jdbc.odbc.JdbcOdbcDriver";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("����̹� �˻� ����!");
		} catch (ClassNotFoundException e) {
			System.err.println("error = " + e);
		}

		url = "jdbc:odbc:nyoung cafe";
		conn = null;
		stmt = null;
		rs = null;
		String url = "jdbc:mysql://localhost/nyoung cafe";
		String sql = "Select * From user";
		try {

			conn = DriverManager.getConnection(url, "root", "apmsetup");

			stmt = conn.createStatement();

			rs = stmt.executeQuery(sql);

			System.out.println("�����ͺ��̽� ���� ����!");

		} catch (Exception e) {
			System.out.println("�����ͺ��̽� ���� ����!");
			e.printStackTrace();
		}
	}

	public static void dbDis() {
		try {
			if (conn != null)
				conn.close();
			if (stmt != null)
				stmt.close();
			System.out.println("�����ͺ��̽� ���� ����!");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	// #####################################################################################
	// �α���
	public static int login(String id, String pw) throws SQLException {

		dbConnect();
		
		rs = stmt.executeQuery("select * from user where custID ='" + id + "'");
		
		if (rs.next() == true) {
			String pwd = rs.getString("custPW");
			
			UserDTO.setCustNum(rs.getString("custNum"));
			UserDTO.setCustID(rs.getString("custID"));
			UserDTO.setCustPW(rs.getString("custPW"));
			UserDTO.setName(rs.getString("custID"));
			UserDTO.setSex(rs.getString("custID"));
			UserDTO.setTel(rs.getString("custID"));
			UserDTO.setEmail(rs.getString("custID"));
			UserDTO.setStamp(rs.getString("custID"));
			
			System.out.println(pwd);
			System.out.println(pw);
			if (pwd.equals(pw)) {
				dbDis();
				return 1;
			} else {
				dbDis();
				return 0;
			}
		} else {
			dbDis();
			return 0;
		}
	}
}
