package user_package;

import DTO.OrderDTO;
import DTO.UserDTO;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.EmptyBorder;

public class WB5_menu extends JFrame {

	protected static final String String = null;
	private JPanel contentPane;
	private JRadioButton sel2;
	private JRadioButton sel3;
	private JRadioButton sel4;

	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	static long count = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WB5_menu frame = new WB5_menu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public WB5_menu() {

		setTitle("\uBA54\uB274\uD310");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 391, 632);
		contentPane = new JPanel();
		contentPane.setLocation(-184, -69);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.setLayout(null);

		JLabel lblNewLabel_1_1 = new JLabel("\uBA54\uB274\uD310");
		lblNewLabel_1_1.setBounds(15, 15, 132, 31);
		lblNewLabel_1_1.setFont(new Font("HY�߰���", Font.PLAIN, 20));
		contentPane.add(lblNewLabel_1_1);

		JPanel panel = new JPanel();
		panel.setBounds(20, 69, 151, 150);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel Espresso = new JLabel("");
		Espresso.setIcon(new ImageIcon("C:\\Users\\ciin0\\OneDrive\\\uBC14\uD0D5 \uD654\uBA74\\espresso.jpg"));
		Espresso.setBounds(0, 0, 150, 150);
		panel.add(Espresso);

		JLabel lblNewLabel_4 = new JLabel("New label");
		lblNewLabel_4.setBounds(0, 0, 150, 150);
		panel.add(lblNewLabel_4);

		JPanel panel_1 = new JPanel();
		panel_1.setBounds(202, 69, 150, 150);
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		JLabel americano = new JLabel("");
		americano.setIcon(new ImageIcon(
				"C:\\Users\\ciin0\\OneDrive\\\uBC14\uD0D5 \uD654\uBA74\\\uC544\uBA54\uB9AC\uCE74\uB178.jpg"));
		americano.setBounds(0, 0, 150, 150);
		panel_1.add(americano);

		JLabel lblNewLabel_5 = new JLabel("New label");
		lblNewLabel_5.setIcon(new ImageIcon("C:\\Users\\ciin0\\OneDrive\\\uBC14\uD0D5 \uD654\uBA74\\americano.jpg"));
		lblNewLabel_5.setBounds(0, 0, 150, 150);
		panel_1.add(lblNewLabel_5);

		JLabel lblNewLabel = new JLabel("\uC5D0\uC2A4\uD504\uB808\uC18C");
		lblNewLabel.setBounds(20, 225, 150, 18);
		lblNewLabel.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("\uC544\uBA54\uB9AC\uCE74\uB178");
		lblNewLabel_1.setBounds(202, 225, 150, 18);
		lblNewLabel_1.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		contentPane.add(lblNewLabel_1);

		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] { "ICE", "HOT" }));
		comboBox.setBounds(20, 250, 54, 24);
		contentPane.add(comboBox);

		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] { "ICE", "HOT" }));
		comboBox_1.setBounds(202, 250, 54, 24);
		contentPane.add(comboBox_1);

		JPanel panel_2 = new JPanel();
		panel_2.setBounds(20, 319, 150, 150);
		contentPane.add(panel_2);

		JLabel caramelMacchiato = new JLabel("");
		caramelMacchiato.setIcon(new ImageIcon(
				"C:\\Users\\ciin0\\OneDrive\\\uBC14\uD0D5 \uD654\uBA74\\\uCE74\uB77C\uBA5C\uB9C8\uB07C\uC544\uB610.jpg"));

		JLabel caramelMachiato = new JLabel("");
		caramelMachiato
				.setIcon(new ImageIcon("C:\\Users\\ciin0\\OneDrive\\\uBC14\uD0D5 \uD654\uBA74\\caramelMacchiato.jpg"));
		GroupLayout gl_panel_2 = new GroupLayout(panel_2);
		gl_panel_2.setHorizontalGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2
						.createSequentialGroup().addGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
								.addComponent(caramelMacchiato).addComponent(caramelMachiato))
						.addContainerGap(28, Short.MAX_VALUE)));
		gl_panel_2.setVerticalGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2
						.createSequentialGroup().addGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
								.addComponent(caramelMacchiato).addComponent(caramelMachiato))
						.addContainerGap(33, Short.MAX_VALUE)));
		panel_2.setLayout(gl_panel_2);

		JPanel panel_3 = new JPanel();
		panel_3.setBounds(202, 319, 150, 150);
		contentPane.add(panel_3);

		JLabel cafeMocha = new JLabel("");
		cafeMocha.setBounds(0, 0, 0, 0);
		cafeMocha.setIcon(
				new ImageIcon("C:\\Users\\ciin0\\OneDrive\\\uBC14\uD0D5 \uD654\uBA74\\\uCE74\uD398\uBAA8\uCE74.jpg"));
		panel_3.setLayout(null);

		JLabel lblNewLabel_7 = new JLabel("");
		lblNewLabel_7.setBounds(0, 0, 150, 150);
		lblNewLabel_7.setIcon(new ImageIcon("C:\\Users\\ciin0\\OneDrive\\\uBC14\uD0D5 \uD654\uBA74\\cafeMocha.jpg"));
		panel_3.add(lblNewLabel_7);
		panel_3.add(cafeMocha);

		JLabel lblNewLabel_2 = new JLabel("\uCE74\uB77C\uBA5C \uB9C8\uB07C\uC544\uB610");
		lblNewLabel_2.setBounds(20, 475, 150, 18);
		lblNewLabel_2.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		contentPane.add(lblNewLabel_2);

		JLabel lblNewLabel_2_1 = new JLabel("\uCE74\uD398\uBAA8\uCE74");
		lblNewLabel_2_1.setBounds(202, 475, 150, 18);
		lblNewLabel_2_1.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		contentPane.add(lblNewLabel_2_1);

		JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setModel(new DefaultComboBoxModel(new String[] { "ICE", "HOT" }));
		comboBox_3.setBounds(20, 500, 54, 24);
		contentPane.add(comboBox_3);

		JComboBox comboBox_3_1 = new JComboBox();
		comboBox_3_1.setModel(new DefaultComboBoxModel(new String[] { "ICE", "HOT" }));
		comboBox_3_1.setBounds(202, 500, 54, 24);
		contentPane.add(comboBox_3_1);

		JButton btnNewButton_2 = new JButton("HOME");
		btnNewButton_2.setBounds(260, 0, 92, 46);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new WB2_main(null, null).setVisible(true);
			}
		});
		contentPane.add(btnNewButton_2);

		JRadioButton sel1 = new JRadioButton("");
		sel1.setBounds(140, 251, 25, 27);
		contentPane.add(sel1);

		sel2 = new JRadioButton("");
		sel2.setBounds(329, 251, 25, 27);
		contentPane.add(sel2);

		sel3 = new JRadioButton("");
		sel3.setBounds(145, 499, 25, 27);
		contentPane.add(sel3);

		sel4 = new JRadioButton("");
		sel4.setBounds(329, 499, 25, 27);
		contentPane.add(sel4);

		JButton btnNewButton = new JButton("\uC120\uD0DD \uC644\uB8CC");
		btnNewButton.setBounds(135, 550, 105, 27);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new WB6_order().setVisible(true);
			}
		});
		contentPane.add(btnNewButton);

		JSpinner espressor_spinner = new JSpinner();
		espressor_spinner.setModel(new SpinnerNumberModel(0, 0, 10, 1));
		espressor_spinner.setBounds(80, 250, 39, 24);
		contentPane.add(espressor_spinner);

		JSpinner americano_spinner = new JSpinner();
		americano_spinner.setModel(new SpinnerNumberModel(0, 0, 10, 1));
		americano_spinner.setBounds(264, 250, 39, 24);
		contentPane.add(americano_spinner);

		JSpinner caramelMachiatospinner = new JSpinner();
		caramelMachiatospinner.setModel(new SpinnerNumberModel(0, 0, 10, 1));
		caramelMachiatospinner.setBounds(80, 500, 39, 24);
		contentPane.add(caramelMachiatospinner);

		JSpinner cafeMocha_spinner = new JSpinner();
		cafeMocha_spinner.setModel(new SpinnerNumberModel(0, 0, 10, 1));
		cafeMocha_spinner.setBounds(264, 500, 39, 24);
		contentPane.add(cafeMocha_spinner);

		JLabel lblNewLabel_3 = new JLabel("2500\uC6D0");
		lblNewLabel_3.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(20, 280, 62, 18);
		contentPane.add(lblNewLabel_3);

		JLabel lblNewLabel_3_1 = new JLabel("3000\uC6D0");
		lblNewLabel_3_1.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_3_1.setBounds(202, 280, 62, 18);
		contentPane.add(lblNewLabel_3_1);

		JLabel lblNewLabel_3_1_1 = new JLabel("4000\uC6D0");
		lblNewLabel_3_1_1.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_3_1_1.setBounds(20, 530, 62, 18);
		contentPane.add(lblNewLabel_3_1_1);

		JLabel lblNewLabel_3_1_1_1 = new JLabel("4000\uC6D0");
		lblNewLabel_3_1_1_1.setFont(new Font("HY�߰���", Font.PLAIN, 15));
		lblNewLabel_3_1_1_1.setBounds(202, 530, 62, 18);
		contentPane.add(lblNewLabel_3_1_1_1);
	}

	// #####################################################################################
	// - DB connect

	public static void dbConnect() {
		driver = "sun.jdbc.odbc.JdbcOdbcDriver";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("����̹� �˻� ����!");
		} catch (ClassNotFoundException e) {
			System.err.println("error = " + e);
		}

		url = "jdbc:odbc:nyoung cafe";
		conn = null;
		stmt = null;
		rs = null;
		String url = "jdbc:mysql://localhost/nyoung cafe";
		String sql = "Select * From menu";
		try {

			conn = DriverManager.getConnection(url, "root", "apmsetup");

			stmt = conn.createStatement();

			rs = stmt.executeQuery(sql);

			System.out.println("�����ͺ��̽� ���� ����!");

		} catch (Exception e) {
			System.out.println("�����ͺ��̽� ���� ����!");
			e.printStackTrace();
		}
	}

	public static void dbDis() {
		try {
			if (conn != null)
				conn.close();
			if (stmt != null)
				stmt.close();
			System.out.println("�����ͺ��̽� ���� ����!");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static int query(String order, String sql) throws SQLException {

		dbConnect();

		int result = 1;

		if (order == "select") {
			rs = stmt.executeQuery(sql);

			if (rs.next() == false) {
				result = 0;
			} else {
				result = 1;
			}

		}

		// update, insert, delete�� �����
		else {
			result = stmt.executeUpdate(sql);
		}

		dbDis();

		return result;

	}

	public static void orderInsert() throws SQLException {
			String custID = UserDTO.getCustID();
			System.out.println(custID);
			
			String menuName = OrderDTO.getmenuName();
			System.out.println(menuName);
			
			int check = query("insert", "insert into ORDER(custID, menuName, number, sumPrice) values ('"+custID+"','"+menuName+"','"++"','"++"')");
		}

}
