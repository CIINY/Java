package user_package;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import DTO.UserDTO;

public class WB9_branchCheck extends JFrame implements ActionListener {

	JOptionPane m = new JOptionPane();

	private JPanel contentPane;
//	private JLabel lblNewLabel_1;
	private JTable table;

	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static String tmpstr;
	static ResultSet rs;
	static long count = 0;

	JButton back_b, search_b;

	static String[] head = new String[] { "������", "�ּ�", "�����ð�" };
	static DefaultTableModel model1 = new DefaultTableModel(head, 0);

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) throws SQLException {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WB9_branchCheck frame = new WB9_branchCheck();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		dbConnect();
		query("select", "select * from office where branchNum = 1");
		count = 1;
		viewData();
		dbDis();
	}

//	private String[][] daten = {};
//	private JFrame f;

	/**
	 * Create the frame.
	 */
	public WB9_branchCheck() {
		super();
		setTitle("\uC9C0\uC810 \uC870\uD68C");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 632);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);

		setContentPane(contentPane);

		JLabel title = new JLabel("\uC9C0\uC810 \uC870\uD68C");
		title.setFont(new Font("HY�߰���", Font.PLAIN, 20));
		title.setBounds(15, 15, 100, 28);
		contentPane.add(title);

		JButton back_b = new JButton("\uD648\uC73C\uB85C");
		back_b.setFont(new Font("����", Font.PLAIN, 16));
		back_b.setBounds(344, 529, 124, 28);
		back_b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				new WB2_main(UserDTO.getCustID(), UserDTO.getCustPW()).setVisible(true);
			}
		});
		contentPane.add(back_b);
		
		
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(14, 75, 754, 442);
		contentPane.add(panel);
		panel.setLayout(null);

		table = new JTable(model1);
		table.setFont(new Font("����", Font.PLAIN, 14));
		table.setPreferredScrollableViewportSize(new Dimension(600, 250));
		table.setFillsViewportHeight(true);

		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(0, 0, 754, 442);
		panel.add(scrollPane);
		scrollPane.setViewportView(table);

		contentPane.setVisible(true);

		/*
		 * setTitle("\uC9C0\uC810 \uC870\uD68C");
		 * setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); setBounds(100, 100, 391,
		 * 632); contentPane = new JPanel(); contentPane.setBorder(new EmptyBorder(5, 5,
		 * 5, 5)); setContentPane(contentPane); contentPane.setLayout(null);
		 * 
		 * JButton btnNewButton_2 = new JButton("HOME"); btnNewButton_2.setBounds(281,
		 * 0, 92, 46); btnNewButton_2.addActionListener(new ActionListener() { public
		 * void actionPerformed(ActionEvent arg0) { setVisible(false); new
		 * WB2_main(null, null).setVisible(true); } }); contentPane.setLayout(null);
		 * contentPane.add(btnNewButton_2);
		 * 
		 * lblNewLabel_1 = new JLabel("\uC9C0\uC810 \uC870\uD68C");
		 * lblNewLabel_1.setBounds(15, 15, 132, 31); lblNewLabel_1.setFont(new
		 * Font("HY�߰���", Font.PLAIN, 20)); contentPane.add(lblNewLabel_1);
		 * 
		 * JScrollPane scrollPane = new JScrollPane(); scrollPane.setBounds(15, 112,
		 * 344, 435); contentPane.add(scrollPane);
		 * 
		 * table = new JTable(); table.setModel(new DefaultTableModel(new Object[][] {},
		 * new String[] { "B.O", "address", "Time" }) {
		 * 
		 * 
		 * 
		 * private static final long serialVersionUID = 3974075636657067926L; Class[]
		 * columnTypes = new Class[] { String.class, String.class, String.class };
		 * 
		 * public Class getColumnClass(int columnIndex) { return
		 * columnTypes[columnIndex]; }
		 * 
		 * boolean[] columnEditables = new boolean[] { false, true, true };
		 * 
		 * public boolean isCellEditable(int row, int column) { return
		 * columnEditables[column]; } });
		 */

		table.getColumnModel().getColumn(0).setPreferredWidth(95);
		table.getColumnModel().getColumn(1).setPreferredWidth(300);
		table.getColumnModel().getColumn(2).setPreferredWidth(100);
		scrollPane.setViewportView(table);

	}

	// #####################################################################################
	// - DB connect

	public static void dbConnect() {
		driver = "sun.jdbc.odbc.JdbcOdbcDriver";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("����̹� �˻� ����!");
		} catch (ClassNotFoundException e) {
			System.err.println("error = " + e);
		}

		url = "jdbc:odbc:nyoung cafe";
		conn = null;
		stmt = null;
		rs = null;
		String url = "jdbc:mysql://localhost/nyoung cafe";
		String sql = "Select * From office";
		try {

			conn = DriverManager.getConnection(url, "root", "apmsetup");

			stmt = conn.createStatement();

			rs = stmt.executeQuery(sql);

			System.out.println("�����ͺ��̽� ���� ����!");

		} catch (Exception e) {
			System.out.println("�����ͺ��̽� ���� ����!");
			e.printStackTrace();
		}
	}

	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			rs = stmt.executeQuery(sql);
		} else {
			stmt.executeUpdate(sql);
		}
	}

	public static void viewData() throws SQLException {
		if (!rs.next()) {
			System.out.println("!rs.next()");
			count--;
		} else {
			try {
				query("select", "select * from office");

				while (rs.next()) {
					model1.addRow(new Object[] { rs.getString("branchName"), rs.getString("branchLocation"),
							rs.getString("time") });
				}
			} catch (Exception e1) {
				e1.getStackTrace();
			}
		}
	}

	public static void dbDis() {
		try {
			if (conn != null)
				conn.close();
			if (stmt != null)
				stmt.close();
			System.out.println("�����ͺ��̽� ���� ����!");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == back_b) {
			JOptionPane.showMessageDialog(null, "�ý��� ����");
			System.exit(0);
		}
	}
}
