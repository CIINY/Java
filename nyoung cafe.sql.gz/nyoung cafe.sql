-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- 호스트: localhost
-- 처리한 시간: 20-12-13 20:00 
-- 서버 버전: 5.1.41
-- PHP 버전: 5.2.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 데이터베이스: `nyoung cafe`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `manager`
--

CREATE TABLE IF NOT EXISTS `manager` (
  `ID` varchar(20) CHARACTER SET utf8 NOT NULL,
  `PW` varchar(20) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- 테이블의 덤프 데이터 `manager`
--

INSERT INTO `manager` (`ID`, `PW`) VALUES
('in0302', 'dlsdud12');

-- --------------------------------------------------------

--
-- 테이블 구조 `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `menuNumber` int(20) NOT NULL AUTO_INCREMENT,
  `menuName` varchar(15) CHARACTER SET utf8 NOT NULL,
  `icehot` varchar(20) CHARACTER SET utf8 NOT NULL,
  `price` int(10) NOT NULL,
  PRIMARY KEY (`menuNumber`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- 테이블의 덤프 데이터 `menu`
--

INSERT INTO `menu` (`menuNumber`, `menuName`, `icehot`, `price`) VALUES
(7, 'americano', '(ICE)', 3000),
(5, 'espresso', '(ICE)', 2500),
(6, 'espresso', '(HOT)', 2500),
(8, 'americano', '(HOT)', 3000),
(9, 'caramelMachiato', '(ICE)', 4000),
(10, 'caramelMachiato', '(HOT)', 4000),
(11, 'cafeMocha', '(ICE)', 4000),
(12, 'cafeMocha', '(HOT)', 4000);

-- --------------------------------------------------------

--
-- 테이블 구조 `office`
--

CREATE TABLE IF NOT EXISTS `office` (
  `branchNum` int(30) NOT NULL AUTO_INCREMENT,
  `branchName` varchar(30) NOT NULL,
  `branchLocation` varchar(80) NOT NULL,
  `time` varchar(20) NOT NULL,
  PRIMARY KEY (`branchNum`),
  UNIQUE KEY `branchName` (`branchName`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- 테이블의 덤프 데이터 `office`
--

INSERT INTO `office` (`branchNum`, `branchName`, `branchLocation`, `time`) VALUES
(1, '녕카페 본점', '부산광역시 사상구 사상로 201 (괘법동)', '09:00 ~ 22:00'),
(2, '녕카페 양정점', '부산광역시 부산진구 양정1동 중앙대로 900', '09:00 ~ 22:00'),
(3, '녕카페 서면점', '부산광역시 부산진구 부전2동 중앙대로 672', '09:00 ~ 23:00'),
(4, '녕카페 해운대점', '부산광역시 해운대구 우동 마린시티2로 38', '09:00 ~ 22:00');

-- --------------------------------------------------------

--
-- 테이블 구조 `orderlist`
--

CREATE TABLE IF NOT EXISTS `orderlist` (
  `orderNum` int(20) NOT NULL AUTO_INCREMENT,
  `custID` varchar(20) NOT NULL,
  `menuName` varchar(200) NOT NULL,
  `number` int(10) NOT NULL,
  `sumPrice` int(255) NOT NULL,
  `orderDate` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`orderNum`),
  KEY `custID` (`custID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=95 ;

--
-- 테이블의 덤프 데이터 `orderlist`
--

INSERT INTO `orderlist` (`orderNum`, `custID`, `menuName`, `number`, `sumPrice`, `orderDate`) VALUES
(94, '123', 'caramelMachiato(HOT)', 5, 20000, '2020-12-12'),
(93, '123', 'caramelMachiato(HOT)', 5, 20000, '2020-12-12'),
(92, '123', 'caramelMachiato(HOT)', 5, 20000, '2020-12-02'),
(91, '123', 'americano(HOT)', 4, 12000, '2020-12-02'),
(90, '123', 'espresso(HOT)', 3, 7500, '2020-12-02'),
(89, '123', 'espresso(HOT)', 2, 5000, '2020-12-02'),
(88, '123', 'americano(HOT)', 1, 3000, '2020-12-02');

-- --------------------------------------------------------

--
-- 테이블 구조 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `custNum` int(20) NOT NULL AUTO_INCREMENT,
  `custID` varchar(20) CHARACTER SET latin1 NOT NULL,
  `custPW` varchar(30) CHARACTER SET latin1 NOT NULL,
  `name` varchar(10) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `tel` varchar(200) NOT NULL,
  `email` varchar(500) NOT NULL,
  `stamp` int(200) NOT NULL DEFAULT '0',
  PRIMARY KEY (`custNum`),
  UNIQUE KEY `custID` (`custID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- 테이블의 덤프 데이터 `user`
--

INSERT INTO `user` (`custNum`, `custID`, `custPW`, `name`, `sex`, `tel`, `email`, `stamp`) VALUES
(1, '1231', '1231', '123', 'male', '10123123', '123', 0),
(2, '123', '123', '123', 'female', '123', '123', 7),
(3, '1234', '123', '123', 'male', '10123123', '123', 0),
(4, '0213', 'dlsdud12', '최인영', 'female', '1095592303', 'ciy9559', 0),
(5, '987', '987', '987', 'female', '1195592303', '987', 0),
(6, '789', '789', '789', 'female', '1195592303', '789', 0),
(7, '5555', '1234', '1234', 'female', '1012341234', '1234@naver.com', 0),
(8, '4444', '4444', '4444', 'male', '1044444444', '44444@gmail.com', 0),
(9, '3333', '3333', '3333', 'male', '1033333333', '3333@naver.com', 0),
(13, 'asdf', 'asdf', 'asdf', 'female', '010asdfasdf', 'asdf@naver.com', 4),
(11, 'asdfff', 'asdf', 'adsf', 'female', '010asdfasdf', 'asdf@naver.com', 0),
(16, 'asdffff', 'asdfff', 'asdffff', 'female', '010asdfasfas', 'asdf@naver.com', 0);
